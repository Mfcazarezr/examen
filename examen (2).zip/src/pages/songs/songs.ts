import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the SongsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-songs',
  templateUrl: 'songs.html',
})
export class SongsPage {
  songsB = ['1.Que Me Quedes Tú', '2. Inevitable', '3.Antología','Moscas en la Casa', 'Sale el Sol']            

  constructor(public navCtrl: NavController, public navParams: NavParams) {
                            
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SongsPage');
  }

}











