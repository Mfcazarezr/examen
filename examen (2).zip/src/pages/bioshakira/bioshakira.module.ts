import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BioshakiraPage } from './bioshakira';

@NgModule({
  declarations: [
    BioshakiraPage,
  ],
  imports: [
    IonicPageModule.forChild(BioshakiraPage),
  ],
})
export class BioshakiraPageModule {}
