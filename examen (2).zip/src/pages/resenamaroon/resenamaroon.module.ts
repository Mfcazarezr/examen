import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResenamaroonPage } from './resenamaroon';

@NgModule({
  declarations: [
    ResenamaroonPage,
  ],
  imports: [
    IonicPageModule.forChild(ResenamaroonPage),
  ],
})
export class ResenamaroonPageModule {}
