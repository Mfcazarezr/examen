import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Resenas1Page } from './resenas1';

@NgModule({
  declarations: [
    Resenas1Page,
  ],
  imports: [
    IonicPageModule.forChild(Resenas1Page),
  ],
})
export class Resenas1PageModule {}
