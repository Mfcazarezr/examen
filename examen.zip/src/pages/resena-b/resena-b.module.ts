import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResenaBPage } from './resena-b';

@NgModule({
  declarations: [
    ResenaBPage,
  ],
  imports: [
    IonicPageModule.forChild(ResenaBPage),
  ],
})
export class ResenaBPageModule {}
