import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Tracks3Page } from './tracks3';

@NgModule({
  declarations: [
    Tracks3Page,
  ],
  imports: [
    IonicPageModule.forChild(Tracks3Page),
  ],
})
export class Tracks3PageModule {}
