import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BioluisPage } from './bioluis';

@NgModule({
  declarations: [
    BioluisPage,
  ],
  imports: [
    IonicPageModule.forChild(BioluisPage),
  ],
})
export class BioluisPageModule {}
