import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Tracks2Page } from './tracks2';

@NgModule({
  declarations: [
    Tracks2Page,
  ],
  imports: [
    IonicPageModule.forChild(Tracks2Page),
  ],
})
export class Tracks2PageModule {}
