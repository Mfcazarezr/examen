import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Tracks1Page } from './tracks1';

@NgModule({
  declarations: [
    Tracks1Page,
  ],
  imports: [
    IonicPageModule.forChild(Tracks1Page),
  ],
})
export class Tracks1PageModule {}
