import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BioAdamPage } from './bio-adam';

@NgModule({
  declarations: [
    BioAdamPage,
  ],
  imports: [
    IonicPageModule.forChild(BioAdamPage),
  ],
})
export class BioAdamPageModule {}
